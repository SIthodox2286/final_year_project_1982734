% The larger the number, the higher/latest version it is

rbeastGitHubVersion = 0.9411;