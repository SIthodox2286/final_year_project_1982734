#pragma once

#include "beastv2_header.h"


extern void AllocInitModelMEM(BEAST2_MODEL_PTR model, BEAST2_OPTIONS_PTR opt, MemPointers* MEM);
 